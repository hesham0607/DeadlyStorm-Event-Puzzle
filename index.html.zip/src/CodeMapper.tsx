import { useState, useEffect } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../convex/_generated/api";
import { toast } from "sonner";

export function CodeMapper() {
  const [inputCode, setInputCode] = useState("");
  const [showAddForm, setShowAddForm] = useState(false);
  const [newCode, setNewCode] = useState("");
  const [newText, setNewText] = useState("");
  const [userId, setUserId] = useState("");
  
  useEffect(() => {
    let storedUserId = localStorage.getItem('userId');
    if (!storedUserId) {
      storedUserId = 'user_' + Math.random().toString(36).substr(2, 9);
      localStorage.setItem('userId', storedUserId);
    }
    setUserId(storedUserId);
  }, []);
  
  const mappings = useQuery(api.codeMappings.getUserMappings, 
    userId ? { createdBy: userId } : "skip"
  ) || [];
  const resultText = useQuery(api.codeMappings.getTextByCode, 
    inputCode ? { code: inputCode } : "skip"
  );
  
  const addMapping = useMutation(api.codeMappings.addCodeMapping);
  const deleteMapping = useMutation(api.codeMappings.deleteCodeMapping);

  const handleAddMapping = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCode.trim() || !newText.trim()) {
      toast.error("يرجى ملء جميع الحقول");
      return;
    }

    try {
      await addMapping({ 
        code: newCode.trim(), 
        text: newText.trim(),
        createdBy: userId
      });
      setNewCode("");
      setNewText("");
      setShowAddForm(false);
      toast.success("تم إضافة الكود بنجاح!");
    } catch (error: any) {
      toast.error(error.message || "حدث خطأ أثناء إضافة الكود");
    }
  };

  const handleDeleteMapping = async (id: string) => {
    try {
      await deleteMapping({ id: id as any, createdBy: userId });
      toast.success("تم حذف الكود بنجاح!");
    } catch (error) {
      toast.error("حدث خطأ أثناء حذف الكود");
    }
  };

  return (
    <div className="space-y-8">
      {/* قسم إدخال الكود */}
      <div className="bg-gray-900/50 border border-orange-600/30 rounded-lg shadow-lg p-6">
        <h2 className="text-2xl font-bold mb-4 text-orange-400">أدخل الكود</h2>
        <div className="space-y-4">
          <input
            type="text"
            value={inputCode}
            onChange={(e) => setInputCode(e.target.value)}
            placeholder="اكتب الكود هنا..."
            className="w-full px-4 py-3 border border-orange-600/30 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 text-lg bg-black text-orange-400 placeholder-orange-600/50"
          />
          
          {inputCode && (
            <div className="mt-4 p-4 bg-gray-900/70 rounded-lg border border-orange-600/20">
              <h3 className="font-semibold text-orange-300 mb-2">النتيجة:</h3>
              {resultText ? (
                <div>
                  <p className="text-lg text-orange-200 leading-relaxed">{resultText}</p>
                  <p className="text-sm text-green-400 mt-2">✅ تم العثور على الكود</p>
                </div>
              ) : (
                <p className="text-orange-600/70 italic">❌ لا يوجد نص مقترن بهذا الكود</p>
              )}
            </div>
          )}
        </div>
      </div>

      {/* قسم إضافة كود جديد */}
      <div className="bg-gray-900/50 border border-orange-600/30 rounded-lg shadow-lg p-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-2xl font-bold text-orange-400">إدارة الأكواد</h2>
          <button
            onClick={() => setShowAddForm(!showAddForm)}
            className="px-4 py-2 bg-orange-600 text-black rounded-lg hover:bg-orange-500 transition-colors font-semibold"
          >
            {showAddForm ? "إلغاء" : "إضافة كود جديد"}
          </button>
        </div>

        {showAddForm && (
          <form onSubmit={handleAddMapping} className="space-y-4 mb-6 p-4 bg-gray-900/70 rounded-lg border border-orange-600/20">
            <div>
              <label className="block text-sm font-medium text-orange-300 mb-2">
                الكود
              </label>
              <input
                type="text"
                value={newCode}
                onChange={(e) => setNewCode(e.target.value)}
                placeholder="أدخل الكود..."
                className="w-full px-3 py-2 border border-orange-600/30 rounded-md focus:ring-2 focus:ring-orange-500 focus:border-orange-500 bg-black text-orange-400 placeholder-orange-600/50"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-orange-300 mb-2">
                النص المقترن
              </label>
              <textarea
                value={newText}
                onChange={(e) => setNewText(e.target.value)}
                placeholder="أدخل النص الذي سيظهر..."
                rows={3}
                className="w-full px-3 py-2 border border-orange-600/30 rounded-md focus:ring-2 focus:ring-orange-500 focus:border-orange-500 bg-black text-orange-400 placeholder-orange-600/50"
                required
              />
            </div>
            <button
              type="submit"
              className="w-full px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors font-semibold"
            >
              حفظ الكود
            </button>
          </form>
        )}

        {/* قائمة الأكواد الموجودة */}
        <div className="space-y-3">
          <h3 className="text-lg font-semibold text-orange-300">الأكواد التي أنشأتها ({mappings.length})</h3>
          {mappings.length === 0 ? (
            <p className="text-orange-600/70 italic">لا توجد أكواد محفوظة بعد</p>
          ) : (
            <div className="grid gap-3">
              {mappings.map((mapping) => (
                <div key={mapping._id} className="flex items-start justify-between p-3 border border-orange-600/30 rounded-lg hover:bg-gray-900/30 bg-gray-900/20 transition-colors">
                  <div className="flex-1">
                    <div className="font-mono text-sm bg-orange-600/20 px-2 py-1 rounded mb-2 inline-block text-orange-300 border border-orange-600/30">
                      {mapping.code}
                    </div>
                    <p className="text-orange-200">{mapping.text}</p>
                  </div>
                  <button
                    onClick={() => handleDeleteMapping(mapping._id)}
                    className="mr-3 px-3 py-1 text-red-400 hover:bg-red-900/20 rounded transition-colors border border-red-600/30"
                    title="حذف"
                  >
                    🗑️
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
