import { useState } from "react";
import { Toaster } from "sonner";
import { CodeMapper } from "./CodeMapper";

export default function App() {
  const [isDark, setIsDark] = useState(true);

  const toggleTheme = () => {
    setIsDark(!isDark);
  };

  return (
    <div className="min-h-screen flex flex-col bg-black text-orange-400" dir="rtl">
      <header className="sticky top-0 z-10 bg-black/90 backdrop-blur-sm h-16 flex justify-between items-center border-b border-orange-600/30 shadow-sm px-4">
        <h2 className="text-xl font-semibold text-orange-400">DeadlyStorm Event Puzzle</h2>
        <button
          onClick={toggleTheme}
          className="p-2 rounded-lg bg-orange-600/20 hover:bg-orange-600/30 transition-colors text-orange-400"
          title={isDark ? "التبديل للوضع الفاتح" : "التبديل للوضع المظلم"}
        >
          {isDark ? "🌞" : "🌙"}
        </button>
      </header>
      <main className="flex-1 p-8">
        <div className="w-full max-w-4xl mx-auto">
          <Content />
        </div>
      </main>
      <Toaster />
    </div>
  );
}

function Content() {
  return (
    <div className="flex flex-col gap-8">
      <div className="text-center">
        <h1 className="text-4xl font-bold text-orange-400 mb-4">DeadlyStorm Event Puzzle</h1>
        <p className="text-xl text-orange-300">
          حل الألغاز واكتشف الأسرار المخفية
        </p>
      </div>
      <CodeMapper />
    </div>
  );
}
