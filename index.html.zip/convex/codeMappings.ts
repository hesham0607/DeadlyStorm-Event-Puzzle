import { query, mutation } from "./_generated/server";
import { v } from "convex/values";

export const getUserMappings = query({
  args: { createdBy: v.optional(v.string()) },
  handler: async (ctx, args) => {
    if (!args.createdBy) {
      return [];
    }
    
    return await ctx.db
      .query("codeMappings")
      .withIndex("by_creator", (q) => q.eq("createdBy", args.createdBy))
      .collect();
  },
});

export const getTextByCode = query({
  args: { code: v.string() },
  handler: async (ctx, args) => {
    // البحث عن الكود في جميع الأكواد الموجودة (ليس فقط للمستخدم الحالي)
    const mapping = await ctx.db
      .query("codeMappings")
      .filter((q) => q.eq(q.field("code"), args.code))
      .first();
    
    return mapping?.text || null;
  },
});

export const addCodeMapping = mutation({
  args: {
    code: v.string(),
    text: v.string(),
    createdBy: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    // التحقق من وجود الكود مسبقاً في جميع الأكواد
    const existing = await ctx.db
      .query("codeMappings")
      .filter((q) => q.eq(q.field("code"), args.code))
      .first();
    
    if (existing) {
      throw new Error("هذا الكود موجود مسبقاً! يرجى اختيار كود آخر.");
    } else {
      // إضافة كود جديد
      return await ctx.db.insert("codeMappings", {
        code: args.code,
        text: args.text,
        createdBy: args.createdBy,
      });
    }
  },
});

export const deleteCodeMapping = mutation({
  args: { 
    id: v.id("codeMappings"),
    createdBy: v.optional(v.string())
  },
  handler: async (ctx, args) => {
    const mapping = await ctx.db.get(args.id);
    if (!mapping || mapping.createdBy !== args.createdBy) {
      throw new Error("غير مسموح بحذف هذا الكود");
    }
    
    await ctx.db.delete(args.id);
  },
});
