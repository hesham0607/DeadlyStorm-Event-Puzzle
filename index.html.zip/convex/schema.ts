import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  codeMappings: defineTable({
    code: v.string(),
    text: v.string(),
    createdBy: v.optional(v.string()), // معرف بسيط للمنشئ
    userId: v.optional(v.string()), // للتوافق مع البيانات القديمة
  }).index("by_code", ["code"])
    .index("by_creator", ["createdBy"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
